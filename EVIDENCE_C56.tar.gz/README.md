# C56 / R18 — Zabbix usergroup effective-permission DENY bypass (DEV-5196 patch-gap)

## Versions
- Vulnerable: Zabbix **7.4.16** and **7.0.32** (latest stable tags as of 2026-11-02)
- Fix: DEV-5196 on `release/7.4` `2f2d7fb700` (2026-10-27) and `release/7.0` `fbe2904def` — **not** in released tags
- Tarball: `zabbix-7.4.16.tar.gz` sha256 `0e2c391dc184acce8e34250e7326a51e19c8bcee31e67b8497f5526247ecd261`
- Sink file sha256 (7.4.16): `5a96a3650c948d0fa99849238f23a3c11c1766f91641b37f9c8aeb0aa6c981da`

## Root cause
`CUserGroup::updateRights` → `getUgSetPermissions` only aggregates **changed** user groups into the new effective permission. Unchanged sibling groups' **PERM_DENY** is ignored when computing the new `permission` map row. Official docs: DENY always overrides; this path violates that.

## Trigger
`usergroup.update` (Super Admin). Same `updateForce` also invoked from `CHostGroup` / `CTemplateGroup` when rights are rewritten.

## Reproduce (offline, no network, synthetic data)
```bash
/workspace/bounty-research/tools/php/php harness_deny_bypass.php
/workspace/bounty-research/tools/php/php harness_negatives.php
```
Expected: PRE-FIX ends with READ (DENY wiped); FIXED keeps DENY. Negatives: 4/4 PASS.

## Impact
After a routine Super Admin rights edit on one overlapping user group, users whose other group still has DENY on a host/template group incorrectly receive READ/READ_WRITE in the `permission` table — host/macro/item disclosure and potential write on denied hosts.
